package com.example.tugasintent;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private static final String LOG_TAG = MainActivity.class.getSimpleName();
    public static final String EXTRA_MESSAGE = "com.example.intent.extra.MESSAGE";
    private EditText eEditTextNama, eEditTextAlamat, eEditTextNohp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        eEditTextNama = (EditText) findViewById(R.id.editText_nama);
        eEditTextAlamat = (EditText) findViewById(R.id.editText_alamat);
        eEditTextNohp = (EditText) findViewById(R.id.editText_nohp);
    }

    public void launchSecondActivity(View view) {
        Log.d(LOG_TAG, "Button clicked!");
        Intent intent = new Intent(this, SecondActivity.class);

        String pesan1 = eEditTextNama.getText().toString();
        String pesan2 = eEditTextAlamat.getText().toString();
        String pesan3 = eEditTextNohp.getText().toString();

        intent.putExtra(EXTRA_MESSAGE, "Nama   : "+pesan1+"\nAlamat : "+pesan2+"\nNo HP  : "+pesan3);
        startActivity(intent);
    }
}
